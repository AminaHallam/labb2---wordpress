<?php 

/*
Plugin name: ahPlugin 
description: Ett plugin för reklam
Version: 1.0
Author: Amina Hallam 
Text Domain: AH-plugin

*/ 


// undviker direkt åtkomst till plugin-filen
defined('ABSPATH') or die('Oups !');





add_action('the_content', 'storefront_credit'); 


function storefront_credit($content){


      $promo = '<section style="background: #dfad9b61; padding: 2rem; text-align: center;">';
      $promo .= '<p>Vill du lära dig mer om klättring ? <a href="http://localhost:3000/labb2-AH/produkt/stora-boken-om-klattring/">Här hittar du instruktionsboken</a> ! ;)</p>';
      $promo .= '</section>'; 
      
      $fullcontent = $promo.$content;
  
      return $fullcontent; 
  
  
  }
  


/* function ah_add_promo($the_content){

  if( !is_user_logged_in() ) { 

        $promo = '<section style="background: #dfad9b61; padding: 2rem; text-align: center;">';
        $promo .= '<p>Vill du lära dig mer om klättring ? <a href="http://localhost:3000/labb2-AH/produkt/stora-boken-om-klattring/">Här hittar du instruktionsboken</a> ! ;)</p>';
        $promo .= '</section>'; 
        
        return $the_content.$promo;
    }; 


}

add_action('the_content', 'ah_add_promo'); */

/* OBS!! fixa pluginet -- content försvinner -- Ska synas ovanför pluginet  */


?> 